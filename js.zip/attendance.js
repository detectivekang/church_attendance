async function loadAttendanceForServices() {
  attendance = {};
  const results = await Promise.all(
    services.map((s) => churchCol("attendance").doc(s.id).get()),
  );
  services.forEach((s, i) => {
    attendance[s.id] = results[i].exists ? results[i].data() : {};
  });
}

function renderServiceSelect() {
  const sel = document.getElementById("serviceSelect");
  sel.innerHTML = "";
  const sorted = [...services].sort((a, b) => b.date.localeCompare(a.date));
  sorted.forEach((s) => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = `${fmtDate(s.date)} · ${s.label}`;
    if (s.id === currentServiceId) opt.selected = true;
    sel.appendChild(opt);
  });
}

document.getElementById("serviceSelect").addEventListener("change", (e) => {
  currentServiceId = e.target.value;
  renderAttendList();
});

function getRecord(serviceId, memberId) {
  const raw = (attendance[serviceId] || {})[memberId];
  return normalizeRecord(raw);
}

async function updateRecord(serviceId, memberId, patch) {
  const att = attendance[serviceId] || (attendance[serviceId] = {});
  const cur = normalizeRecord(att[memberId]);
  const next = { ...cur, ...patch };
  att[memberId] = next;
  await churchCol("attendance")
    .doc(serviceId)
    .set({ [memberId]: next }, { merge: true });
  return next;
}

/* =========================================================
   출석 체크 화면
   - [신규] 그룹의 "팀장 출석 관리"가 켜져 있으면 members 배열에
   이미 팀장이 가상 항목(leader:이메일)으로 병합되어 있으므로
   별도 분기 없이 동일하게 도장/헌금/성경 입력이 가능함.
   - 목록은 members.js에서 이미 이름 가나다순으로 정렬되어 있음.
   ========================================================= */
function renderAttendList() {
  const container = document.getElementById("attendList");
  const bulkToolbar = document.getElementById("attendBulkToolbar");
  container.innerHTML = "";
  const editable = canEditAttendance();
  bulkToolbar.style.display =
    editable && members.length > 0 ? "flex" : "none";
  if (members.length === 0) {
    container.innerHTML = '<div class="empty">등록된 팀원이 없습니다.</div>';
    return;
  }
  const showDonation = !!(currentGroupData && currentGroupData.trackDonation);
  const showBible = !!(currentGroupData && currentGroupData.trackBible);

  members.forEach((m, idx) => {
    const rec = getRecord(currentServiceId, m.id);
    const row = document.createElement("div");
    row.className = "roster-row";
    row.innerHTML = `
      <div>
        <span class="roster-num">${idx + 1}.</span>
        <span class="roster-name">${escapeHtml(m.name)}${m.isLeader ? '<span class="leader-tag">팀장</span>' : ""}</span>
      </div>
      <div class="roster-extra">
        ${
          showDonation
            ? `<div class="donation-input-wrap">헌금
              <input type="number" min="0" step="1000" class="donation-input" data-id="${m.id}" value="${rec.donation}" ${editable ? "" : "disabled"} />
              원</div>`
            : ""
        }
        ${
          showBible
            ? `<div class="bible-input-wrap">성경
              <input type="number" min="0" max="66" class="bible-input" data-id="${m.id}" value="${rec.bible}" ${editable ? "" : "disabled"} />
              장</div>`
            : ""
        }
        <button class="stamp-btn ${rec.present ? "present" : ""} ${editable ? "" : "readonly"}" data-id="${m.id}">${rec.present ? "출 석" : "출석 체크"}</button>
      </div>
    `;
    container.appendChild(row);
  });

  if (!editable) return;

  container.querySelectorAll(".stamp-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      const cur = getRecord(currentServiceId, id);
      const next = await updateRecord(currentServiceId, id, {
        present: !cur.present,
      });
      btn.classList.toggle("present", next.present);
      btn.textContent = next.present ? "출 석" : "출석 체크";
      if (next.present) {
        btn.classList.remove("stamp-pop");
        void btn.offsetWidth;
        btn.classList.add("stamp-pop");
      }
      renderStats();
    });
  });

  container.querySelectorAll(".donation-input").forEach((input) => {
    input.addEventListener("change", async () => {
      const id = input.dataset.id;
      let val = Number(input.value);
      if (isNaN(val) || val < 0) val = 0;
      input.value = val;
      await updateRecord(currentServiceId, id, { donation: val });
      renderStats();
    });
  });

  container.querySelectorAll(".bible-input").forEach((input) => {
    input.addEventListener("change", async () => {
      const id = input.dataset.id;
      let val = Number(input.value);
      if (isNaN(val) || val < 0) val = 0;
      if (val > 66) val = 66;
      input.value = val;
      await updateRecord(currentServiceId, id, { bible: val });
      renderStats();
    });
  });
}

/* [신규] 팀장 전용 - 현재 선택된 예배의 전체 팀원 출석을 한 번에
   체크/해제. 팀원마다 개별 저장하지 않고 한 번의 쓰기로 처리 */
async function bulkUpdateAttendance(present) {
  if (!canEditAttendance() || members.length === 0) return;
  const serviceId = currentServiceId;
  const att = attendance[serviceId] || (attendance[serviceId] = {});
  const patch = {};
  members.forEach((m) => {
    const next = { ...normalizeRecord(att[m.id]), present };
    att[m.id] = next;
    patch[m.id] = next;
  });
  try {
    await churchCol("attendance").doc(serviceId).set(patch, { merge: true });
  } catch (err) {
    /* [신규] 저장이 실패했는데도 아무 알림 없이 조용히 끝나버리던 문제를
       고치기 위해, 실패 시에는 반드시 화면에 이유를 보여줌 */
    alert("출석 저장에 실패했습니다: " + (err && err.message ? err.message : err));
    return;
  }
  renderAttendList();
  renderStats();
}

document
  .getElementById("attendCheckAllBtn")
  .addEventListener("click", async () => {
    if (!canEditAttendance() || members.length === 0) return;
    /* [수정] 일부 모바일(인앱 브라우저 등)에서 native confirm()이 동작하지
       않아 버튼을 눌러도 반응이 없던 문제 → 자체 확인 모달로 교체 */
    const ok = await confirmDialog(`${members.length}명 전체를 출석 처리할까요?`);
    if (!ok) return;
    bulkUpdateAttendance(true);
  });

document
  .getElementById("attendUncheckAllBtn")
  .addEventListener("click", async () => {
    if (!canEditAttendance() || members.length === 0) return;
    const ok = await confirmDialog("전체 팀원의 출석을 해제할까요?");
    if (!ok) return;
    bulkUpdateAttendance(false);
  });

/* =========================================================
   전역 상태
   ========================================================= */
let currentUser = null;
let currentRole = null;
let roleScope = {};

/* [신규] 다중 역할 지원 - 한 사람이 여러 팀의 팀장이거나
   팀장+운영자를 동시에 겸할 수 있으므로, roles 문서의 단일 role 대신
   "역할 컨텍스트" 배열을 들고 있다가 그중 하나를 활성 컨텍스트로 사용함.
   컨텍스트 형태: { role: "leader"|"operator", groupId?, categoryId?, label? } */
let userContexts = [];
let activeContextIndex = 0;

let categories = [];
let categoriesCache = {};
let groups = [];
let selectedCategoryId = null;
let currentGroupData = null;
let selectedGroupId = null;

let members = []; // 그룹 상세 화면의 실제 팀원 + (설정 시) 팀장 가상 항목 포함
let services = [];
let attendance = {};
let currentServiceId = null;
let selectedYear = new Date().getFullYear();

let usersList = []; // 가입한 전체 유저 {email, name}
let editingMemberId = null;
let editingGroupId = null;
let editingCategoryId = null;

/* 그룹 관리 화면의 "전체 그룹 상세 통계" 캐시 (요약/상세 테이블에서 공유) */
let categoryDetailData = [];
let categoryDetailOpen = false;
